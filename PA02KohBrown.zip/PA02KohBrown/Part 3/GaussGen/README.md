Requirements:

    Linux machine
    OpenCV
    CMake

How to run:

    From scratch:
        rm CMakeCache.txt
        cmake ../
        Continue to next part

    With current makefile:
        reset; make clean; make
        ./GaussGen <int seed>

Issues: 




Credits:




